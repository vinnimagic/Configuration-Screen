package com.example.settings


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Definindo o estilo aqui direto para não depender do Type.kt
val HeaderTextStyle = TextStyle(
    fontSize = 28.sp,
    fontWeight = FontWeight.ExtraBold
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Usando MaterialTheme padrão do Android para evitar erro de 'SettingsTheme'
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                        SettingsContainer(modifier = Modifier.padding(innerPadding))
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsContainer(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()) // Permite rolar a tela se for pequena
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SettingsHeader()
        SettingsImage()
        SettingsCheckbox()
        SettingsSwitch()
        SettingsSlider()
        SettingsRadioButtons()
        Spacer(modifier = Modifier.height(20.dp))
        SettingsAlertDialog()
    }
}

@Composable
fun SettingsHeader() {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Text(text = "Configurações", style = HeaderTextStyle, modifier = Modifier.padding(end = 8.dp))
        Icon(imageVector = Icons.Default.Settings, contentDescription = null)
    }
}

@Composable
fun SettingsImage() {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = "Imagem de perfil", fontSize = 18.sp)
        // Se der erro aqui, mude ic_launcher_foreground para qualquer imagem que você tenha no drawable
        Icon(
            imageVector = Icons.Default.Settings,
            contentDescription = null,
            modifier = Modifier.size(40.dp).clickable { }
        )
    }
}

@Composable
fun SettingsCheckbox() {
    var isChecked by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = "Aceitar cookies?", fontSize = 16.sp)
        Checkbox(checked = isChecked, onCheckedChange = { isChecked = it })
    }
}

@Composable
fun SettingsSwitch() {
    var isChecked by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = "Usar dados móveis?", fontSize = 16.sp)
        Switch(checked = isChecked, onCheckedChange = { isChecked = it })
    }
}

@Composable
fun SettingsSlider() {
    var sliderValue by remember { mutableStateOf(0.5f) }
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(text = "Tamanho do texto: ${(sliderValue * 100).toInt()}%")
        Slider(value = sliderValue, onValueChange = { sliderValue = it })
    }
}

@Composable
fun SettingsRadioButtons() {
    val options = listOf("PayPal", "Cartão de crédito", "Transferência bancária")
    var selectedOption by remember { mutableStateOf(options[0]) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(text = "Método de pagamento", fontWeight = FontWeight.Bold)
        options.forEach { text ->
            Row(
                Modifier.fillMaxWidth().clickable { selectedOption = text },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = (text == selectedOption), onClick = { selectedOption = text })
                Text(text = text, modifier = Modifier.padding(start = 8.dp))
            }
        }
    }
}

@Composable
fun SettingsAlertDialog() {
    var showDialog by remember { mutableStateOf(false) }
    Button(onClick = { showDialog = true }) {
        Text(text = "Finalizar")
    }
    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(text = "Sair") },
            text = { Text(text = "Tem certeza?") },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Cancelar") }
            }
        )
    }
}