# Atividade: Tela de Configurações - Jetpack Compose

Este projeto foi desenvolvido para a disciplina de Programação Mobile. 
A tela utiliza componentes modernos do Android como Scaffold, Column, Row e estados reativos.

## Funcionalidades
- Alteração de preferências (Checkbox e Switch)
- Seleção de pagamento (Radio Buttons)
- Ajuste de escala (Slider)
- Diálogo de confirmação (AlertDialog)

## Captura de Tela
![Minha Tela de Configurações] 
<img width="1399" height="1015" alt="Captura de tela 2026-04-18 224330" src="https://github.com/user-attachments/assets/400e88e6-0ced-4069-9737-d557a7923dd4" />
